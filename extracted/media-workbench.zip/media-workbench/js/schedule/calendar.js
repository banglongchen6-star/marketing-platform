/* =====================================================================
 * 达人营销 · 内容排期模块 · 双月日历视图 (Phase 2)
 *
 * 暴露：
 *   window.SchedulePage = { render, prevMonth, nextMonth, goToday, ... }
 *   window.openScheduleEditor(scheduleId | null, prefillDate?)  — Phase 3 实现
 * ===================================================================== */
(function () {
  const SD = window.ScheduleData;
  if (!SD) { console.error('[SchedulePage] ScheduleData 未就绪'); return; }

  /* ------------------------- 1. 模块状态 ------------------------- */
  const state = {
    year: 0,
    month: 0,          // 1-12
    tiers: [],         // 层级筛选，空数组 = 全部
    bd_id: '',         // BD 筛选，空 = 全部
  };

  const TIERS = ['头部', '中部', '腰部', '尾部', '素人'];
  const STATUS_LABEL = {
    planned: '计划中', published: '已发布',
  };
  const STATUS_KEYS = Object.keys(STATUS_LABEL);

  function initState() {
    const now = new Date();
    state.year = now.getFullYear();
    state.month = now.getMonth() + 1;
  }

  function fmtMonthLabel(y, m) {
    return `${y} 年 ${m} 月`;
  }

  function pad2(n) { return String(n).padStart(2, '0'); }

  function nextMonthOf(y, m) {
    if (m === 12) return { year: y + 1, month: 1 };
    return { year: y, month: m + 1 };
  }

  function todayStr() {
    const d = new Date();
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  }

  /* ------------------------- 2. 日历网格计算 -------------------------
   * 返回 5-6 周 × 7 天的二维数组，每格 { dateStr, dayNum, isCurrentMonth, isToday }
   */
  function buildMonthGrid(year, month) {
    const first = new Date(year, month - 1, 1);
    const firstWeekday = first.getDay(); // 0=Sun, 6=Sat
    // 我们以周一为起点：weekday=0 表示周一
    const offset = (firstWeekday + 6) % 7;
    const lastOfMonth = new Date(year, month, 0).getDate();
    const gridStart = new Date(year, month - 1, 1 - offset);

    const today = todayStr();
    const cells = [];
    // 总共最多 6 周
    for (let i = 0; i < 42; i++) {
      const d = new Date(gridStart);
      d.setDate(gridStart.getDate() + i);
      const y = d.getFullYear(), m = d.getMonth() + 1, day = d.getDate();
      const dateStr = `${y}-${pad2(m)}-${pad2(day)}`;
      cells.push({
        dateStr,
        dayNum: day,
        weekday: i % 7, // 0=Mon
        isCurrentMonth: m === month,
        isToday: dateStr === today,
      });
      // 若已经到下月且本周已满，可提前结束（最少 5 周）
      if (i >= 34 && d.getMonth() + 1 !== month && (i + 1) % 7 === 0) break;
    }
    // 切成 7 列
    const weeks = [];
    for (let i = 0; i < cells.length; i += 7) weeks.push(cells.slice(i, i + 7));
    return weeks;
  }

  /* ------------------------- 3. 渲染：工具条 ------------------------- */
  function renderToolbar() {
    const next = nextMonthOf(state.year, state.month);
    const tierChip = state.tiers.length
      ? `<span class="sched-filter-chip">层级：${state.tiers.join('、')}
           <span class="clear" onclick="SchedulePage.clearTiers()">×</span></span>`
      : '';
    return `
      <div class="sched-toolbar">
        <div class="sched-month-switcher">
          <button class="sched-month-btn" onclick="SchedulePage.prevMonth()" title="上月">‹</button>
          <div class="sched-month-current">${fmtMonthLabel(state.year, state.month)}</div>
          <button class="sched-month-btn" onclick="SchedulePage.nextMonth()" title="下月">›</button>
          <button class="sched-month-today" onclick="SchedulePage.goToday()">今天</button>
          <span style="margin-left:8px;color:var(--text-muted);font-size:.78rem">
            同时显示 ${state.year}/${state.month} 与 ${next.year}/${next.month}
          </span>
        </div>
        ${renderBdFilter()}
        <button class="btn btn-secondary btn-sm" onclick="SchedulePage.openDictManager()" title="达人类型字典">
          ⚙️ 字典管理
        </button>
        <button class="btn btn-secondary btn-sm" onclick="SchedulePage.openImport()" title="Excel 导入">
          📥 导入
        </button>
        <button class="btn btn-secondary btn-sm" onclick="SchedulePage.openExport()" title="Excel 导出">
          📤 导出
        </button>
        <button class="btn btn-secondary btn-sm" onclick="RecycleBin.open()" title="查看 7 天内删除的排期">
          🗑 回收站${(()=>{ const n = window.RecycleBin?.countActive?.() || 0; return n ? `（${n}）` : ''; })()}
        </button>
        <button class="btn btn-primary btn-sm" onclick="openScheduleEditor(null)">
          ＋ 新增排期
        </button>
      </div>
    `;
  }

  /* ------------------------- 4. 渲染：单个日历 ------------------------- */
  function statusClass(status) {
    return 'sched-status-' + (status || 'planned');
  }

  function renderCard(s) {
    const st = (window.DB?.settlements || []).find(x => x.schedule_id === s.id && !x.settled);
    const amount = st
      ? (parseFloat(st.contract_amount || s.amount) || 0) + (st.bonus_enabled ? (parseFloat(st.bonus_amount) || 0) : 0)
      : (Number(s.amount) || 0);
    const amountText = amount >= 10000
      ? `¥${(amount/10000).toFixed(1)}万`
      : `¥${amount.toLocaleString()}`;
    const tierChip = s.tier
      ? `<span class="sched-card-chip tier">${escapeHtml(s.tier)}</span>` : '';
    const dirChip = s.category_direction
      ? `<span class="sched-card-chip direction" title="达人类型">${escapeHtml(s.category_direction)}</span>` : '';
    const plats = Array.isArray(s.platforms) && s.platforms.length ? s.platforms : (s.platform ? [s.platform] : []);
    const platChip = plats.map(p => `<span class="sched-card-chip platform" title="平台">${escapeHtml(p)}</span>`).join('');
    // BD 归属：左边框色（覆盖默认状态色）+ tooltip
    const bd = s.bd_id ? SD.listBds({ includeInactive: true }).find(b => b.id === s.bd_id) : null;
    const bdStyle = bd ? `style="border-left-color:${bd.color};border-left-width:4px"` : '';
    const bdChip = bd ? `<span class="sched-card-chip" style="background:${bd.color}20;color:${bd.color};font-weight:500" title="BD：${escapeHtml(bd.name)}">${escapeHtml(bd.name)}</span>` : '';
    const titleAttr = [
      STATUS_LABEL[s.status] || s.status || '',
      bd ? `BD：${bd.name}` : '',
      plats.length ? `平台：${plats.join('、')}` : '',
      s.category_direction ? `类型：${s.category_direction}` : '',
      s.tier ? `层级：${s.tier}` : '',
    ].filter(Boolean).join(' · ');
    const homepageLink = s.kol_homepage
      ? `<a class="sched-card-link" href="${escapeHtml(s.kol_homepage)}" target="_blank" rel="noopener noreferrer"
            onclick="event.stopPropagation()" title="新窗口打开达人主页">🔗</a>`
      : '';
    return `
      <div class="sched-card" data-status="${s.status || 'planned'}" ${bdStyle}
           draggable="true"
           ondragstart="event.stopPropagation();SchedulePage._onCardDragStart(event,'${s.id}')"
           ondragend="SchedulePage._onCardDragEnd(event)"
           onclick="event.stopPropagation();openScheduleEditor('${s.id}')"
           oncontextmenu="event.preventDefault();event.stopPropagation();SchedulePage._openStatusMenu(event,'${s.id}')"
           title="${escapeHtml(titleAttr)}">
        <div class="sched-card-row1">
          <span class="sched-card-name">${escapeHtml(s.kol_name || '未命名')}</span>
          ${homepageLink}
        </div>
        <div class="sched-card-row2">
          <span class="sched-card-amount ${statusClass(s.status)}">${amountText}</span>
        </div>
        ${(dirChip || platChip || tierChip || bdChip) ? `<div class="sched-card-meta">${dirChip}${platChip}${tierChip}${bdChip}</div>` : ''}
      </div>
    `;
  }

  function renderCell(cell, schedulesByDate) {
    const items = schedulesByDate[cell.dateStr] || [];
    const classes = ['sched-cal-cell'];
    if (!cell.isCurrentMonth) classes.push('other-month');
    if (cell.isToday) classes.push('today');
    return `
      <div class="${classes.join(' ')}"
           data-date="${cell.dateStr}"
           ondragover="SchedulePage._onCellDragOver(event, this)"
           ondragleave="SchedulePage._onCellDragLeave(event, this)"
           ondrop="SchedulePage._onCellDrop(event, '${cell.dateStr}', this)"
           onclick="openScheduleEditor(null, '${cell.dateStr}')">
        <div class="sched-cal-dayrow">
          <span class="sched-cal-daynum">${cell.dayNum}</span>
          ${cell.isToday ? '<span class="sched-cal-todaybadge">今</span>' : ''}
        </div>
        ${items.map(renderCard).join('')}
      </div>
    `;
  }

  function renderOneCalendar(year, month) {
    const grid = buildMonthGrid(year, month);
    const { start, end } = SD.monthRange(year, month);
    let schedules = SD.listSchedulesInRange(start, end, { tiers: state.tiers });

    // 还要把日历里"跨月"的格子的排期也展示（next month 的开头几天可能落在 prev 月日历）
    // 简化：取整个日历起止区间
    const firstCell = grid[0][0].dateStr;
    const lastCell = grid[grid.length - 1][6].dateStr;
    // listSchedulesInRange end 是 exclusive，加一天
    const endStr = addOneDay(lastCell);
    schedules = SD.listSchedulesInRange(firstCell, endStr, { tiers: state.tiers, bd_id: state.bd_id || undefined });

    const byDate = {};
    schedules.forEach((s) => {
      if (!byDate[s.schedule_date]) byDate[s.schedule_date] = [];
      byDate[s.schedule_date].push(s);
    });
    // 按状态优先级 + 金额降序排
    Object.values(byDate).forEach(arr => arr.sort((a, b) => (b.amount || 0) - (a.amount || 0)));

    // 月度小计（只算当月）
    const monthList = SD.listSchedulesInRange(start, end, { tiers: state.tiers, bd_id: state.bd_id || undefined })
      .filter(s => s.status !== 'cancelled');
    const monthSpent = monthList.reduce((sum, s) => sum + (Number(s.amount) || 0), 0);
    const monthCount = monthList.length;

    const weekHead = ['一','二','三','四','五','六','日']
      .map((w, i) => `<div class="sched-cal-wkhead ${i===5?'sat':i===6?'sun':''}">${w}</div>`).join('');
    const body = grid.map(week => week.map(c => renderCell(c, byDate)).join('')).join('');

    return `
      <div class="sched-cal-card">
        <div class="sched-cal-header">
          <span>${year} 年 ${month} 月</span>
          <span class="sched-cal-month-stats">
            实际花费 <b>¥${monthSpent.toLocaleString()}</b> · 共 <b>${monthCount}</b> 条
          </span>
        </div>
        <div class="sched-cal-grid">
          ${weekHead}
          ${body}
        </div>
      </div>
    `;
  }

  function addOneDay(dateStr) {
    const d = new Date(dateStr + 'T00:00:00');
    d.setDate(d.getDate() + 1);
    return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`;
  }

  /* ------------------------- 5. 渲染：主入口 ------------------------- */
  function render() {
    if (!state.year) initState();
    const page = document.getElementById('page-schedule');
    if (!page) return;
    const next = nextMonthOf(state.year, state.month);
    page.innerHTML = `
      ${renderToolbar()}
      ${renderLegend()}
      <div class="sched-calendars">
        ${renderOneCalendar(state.year, state.month)}
        ${renderOneCalendar(next.year, next.month)}
      </div>
    `;
    // 月度规划表已独立成 /monthly-plan 页面，不在排期页内联展示
  }

  function renderBdFilter() {
    const bds = SD.listBds();
    if (!bds.length) return '';
    const opts = ['<option value="">全部 BD</option>']
      .concat(bds.map(b => `<option value="${escapeHtml(b.id)}" ${state.bd_id===b.id?'selected':''}>${escapeHtml(b.name)}</option>`));
    const cur = bds.find(b => b.id === state.bd_id);
    // 选中 BD 时左边加色块指示当前过滤 BD 颜色
    const dotStyle = cur ? `style="border-left:4px solid ${cur.color}"` : '';
    return `<select class="filter-select" ${dotStyle}
                    onchange="SchedulePage._setBdFilter(this.value)">${opts.join('')}</select>`;
  }

  function _setBdFilter(v) {
    state.bd_id = v || '';
    render();
  }

  function renderLegend() {
    const chips = STATUS_KEYS.map(s => `
      <span class="sched-legend-chip">
        <span class="sched-legend-dot" data-status="${s}"></span>
        <span class="${statusClass(s)}">${STATUS_LABEL[s]}</span>
      </span>
    `).join('');
    return `
      <div class="sched-legend">
        <span class="sched-legend-label">状态：</span>
        ${chips}
        <span class="sched-legend-hint">💡 右键卡片可快速切换状态</span>
      </div>
    `;
  }

  /* ------------------------- 6. 操作 ------------------------- */
  function prevMonth() {
    if (state.month === 1) { state.year--; state.month = 12; }
    else state.month--;
    render();
  }
  function nextMonthAction() {
    if (state.month === 12) { state.year++; state.month = 1; }
    else state.month++;
    render();
  }
  function goToday() { initState(); render(); }

  function openTierFilter(ev) {
    closePopover();
    const btn = ev.currentTarget;
    const rect = btn.getBoundingClientRect();
    const pop = document.createElement('div');
    pop.className = 'sched-filter-pop';
    pop.id = '__tier-pop__';
    pop.style.top = (rect.bottom + window.scrollY + 4) + 'px';
    pop.style.left = (rect.left + window.scrollX) + 'px';
    pop.innerHTML = `
      ${TIERS.map(t => `
        <label><input type="checkbox" value="${t}" ${state.tiers.includes(t)?'checked':''}> ${t}</label>
      `).join('')}
      <div class="actions">
        <button onclick="SchedulePage._applyTiers()">应用</button>
        <button onclick="SchedulePage.clearTiers()">清除</button>
      </div>
    `;
    document.body.appendChild(pop);
    setTimeout(() => document.addEventListener('click', outsideClickClose), 0);
  }
  function outsideClickClose(e) {
    const pop = document.getElementById('__tier-pop__');
    if (!pop) return document.removeEventListener('click', outsideClickClose);
    if (!pop.contains(e.target)) closePopover();
  }
  function closePopover() {
    const pop = document.getElementById('__tier-pop__');
    if (pop) pop.remove();
    document.removeEventListener('click', outsideClickClose);
  }
  function _applyTiers() {
    const pop = document.getElementById('__tier-pop__');
    if (!pop) return;
    state.tiers = [...pop.querySelectorAll('input[type=checkbox]:checked')].map(i => i.value);
    closePopover();
    render();
  }
  function clearTiers() {
    state.tiers = [];
    closePopover();
    render();
  }

  /* ---- 拖拽改日期 ---- */
  let _dragId = null;
  function _onCardDragStart(ev, scheduleId) {
    _dragId = scheduleId;
    if (ev.dataTransfer) {
      ev.dataTransfer.effectAllowed = 'move';
      ev.dataTransfer.setData('text/plain', scheduleId);
    }
    ev.target.classList.add('dragging');
  }
  function _onCardDragEnd(ev) {
    ev.target.classList.remove('dragging');
    document.querySelectorAll('.sched-cal-cell.drop-target').forEach(c => c.classList.remove('drop-target'));
    _dragId = null;
  }
  function _onCellDragOver(ev, cell) {
    if (!_dragId) return;
    ev.preventDefault();
    if (ev.dataTransfer) ev.dataTransfer.dropEffect = 'move';
    cell.classList.add('drop-target');
  }
  function _onCellDragLeave(ev, cell) {
    cell.classList.remove('drop-target');
  }
  function _onCellDrop(ev, newDate, cell) {
    ev.preventDefault();
    cell.classList.remove('drop-target');
    const id = _dragId || (ev.dataTransfer && ev.dataTransfer.getData('text/plain'));
    _dragId = null;
    if (!id) return;
    const s = (window.DB.schedules || []).find(x => x.id === id);
    if (!s) return;
    if (s.schedule_date === newDate) return;

    const oldDate = s.schedule_date;
    const today = todayStr();
    const newStatus = newDate < today ? 'published' : 'planned';

    const doMove = () => {
      try {
        SD.updateSchedule(id, { schedule_date: newDate, status: newStatus });
        window.toast && window.toast(`已移动「${s.kol_name}」 ${oldDate} → ${newDate}`, 'success');
        render();
        if (window.MonthlyPlanPage && document.getElementById('sched-budget-host')) {
          window.MonthlyPlanPage.render();
        }
      } catch (e) {
        window.toast && window.toast('移动失败：' + e.message, 'error');
      }
    };

    if (typeof window._schedImpactWarning === 'function') {
      window._schedImpactWarning(id, 'move', {
        title: '确认移动排期',
        subtitle: `${s.kol_name || '—'} · ${oldDate} → ${newDate}`,
        newDate,
      }, doMove);
    } else {
      doMove();
    }
  }

  /* ---- 右键菜单（状态由日期自动决定，仅展示提示） ---- */
  function _openStatusMenu(ev, scheduleId) {
    closeStatusMenu();
    const s = window.DB.schedules.find(x => x.id === scheduleId);
    if (!s) return;
    const label = STATUS_LABEL[s.status] || s.status;
    const menu = document.createElement('div');
    menu.className = 'sched-status-menu';
    menu.id = '__status-menu__';
    menu.innerHTML = `
      <div class="sched-status-menu-title">当前状态</div>
      <div style="padding:8px 14px;font-size:.85rem;color:var(--text-secondary)">
        <span class="${statusClass(s.status)}">${label}</span>
        <div style="margin-top:6px;font-size:.75rem;color:var(--text-muted)">状态由日期自动决定，拖动卡片可改变日期</div>
      </div>
    `;
    document.body.appendChild(menu);
    const x = Math.min(ev.clientX, window.innerWidth - 200);
    const y = Math.min(ev.clientY, window.innerHeight - 100);
    menu.style.left = (x + window.scrollX) + 'px';
    menu.style.top = (y + window.scrollY) + 'px';
    setTimeout(() => document.addEventListener('click', outsideStatusMenuClose), 0);
  }
  function outsideStatusMenuClose(e) {
    const m = document.getElementById('__status-menu__');
    if (!m || !m.contains(e.target)) closeStatusMenu();
  }
  function closeStatusMenu() {
    const m = document.getElementById('__status-menu__');
    if (m) m.remove();
    document.removeEventListener('click', outsideStatusMenuClose);
  }
  function _setStatus() {} // 已停用，状态由日期自动决定

  // 这些是后续 Phase 的钩子，暂时给提示
  function openDictManager() {
    if (window.DictManager && window.DictManager.open) return window.DictManager.open();
    window.toast ? window.toast('字典管理 (Phase 5 待实现)', 'info') : alert('字典管理 (Phase 5)');
  }
  function openImport() {
    if (window.ImportWizard && window.ImportWizard.open) return window.ImportWizard.open();
    window.toast ? window.toast('Excel 导入 (Phase 6 待实现)', 'info') : alert('Excel 导入 (Phase 6)');
  }
  function openExport() {
    if (window.ExportWizard && window.ExportWizard.open) return window.ExportWizard.open();
    window.toast ? window.toast('Excel 导出 (Phase 7 待实现)', 'info') : alert('Excel 导出 (Phase 7)');
  }

  // Phase 3 之前的 stub
  if (typeof window.openScheduleEditor !== 'function') {
    window.openScheduleEditor = function (id, prefillDate) {
      if (window.ScheduleEditor && window.ScheduleEditor.open) {
        return window.ScheduleEditor.open(id, prefillDate);
      }
      const msg = id ? `编辑排期 ${id}` : `新增排期 ${prefillDate || ''}`;
      window.toast ? window.toast(msg + ' (Phase 3 待实现)', 'info') : alert(msg);
    };
  }

  /* ------------------------- 7. HTML 转义 ------------------------- */
  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[c]));
  }

  /* ------------------------- 8. 暴露 ------------------------- */
  window.SchedulePage = {
    render, prevMonth, nextMonth: nextMonthAction, goToday,
    openTierFilter, clearTiers, _applyTiers,
    openDictManager, openImport, openExport,
    _openStatusMenu, _setStatus, _setBdFilter,
    _onCardDragStart, _onCardDragEnd, _onCellDragOver, _onCellDragLeave, _onCellDrop,
    getState() { return { ...state }; },
    setMonth(y, m) { state.year = y; state.month = m; render(); },
  };

  // 替换旧 renderCalendar：navigate('schedule') 时被调用
  // 旧函数定义在内联 script 里，这里只是覆盖 window 上的引用
  window.renderCalendar = render;

  console.log('[SchedulePage] 已就绪');
})();
